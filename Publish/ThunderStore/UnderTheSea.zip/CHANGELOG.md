<div class="header">
	<h2>Versions 0.X.X</h2>
</div>
<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">0.1.1</td>
			<td align="left">
				<ul>
					<li>Update default config settings to minimize flickering while underwater (thanks soloredis!).</li>
					<li>Hopefully fix debug fly camera bug by caching camera values and reseting to cached values when surfacing.</li>
					<li>Update Jotunn.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">0.1.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>